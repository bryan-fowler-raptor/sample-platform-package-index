from .example import hello

if __name__ == "__main__":
    name = input("What is your first name? ")
    print(hello(name))
