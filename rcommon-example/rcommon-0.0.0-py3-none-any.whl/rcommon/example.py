def hello(name: str) -> str:
    """A simple greeting.
    Args:
        name (str): Name to greet.
    Returns:
        str: greeting message!
    """
    return f"Hello {name}!!!!!!"

TEST_VAR = 'oh yeah'
TEST_VAR2 = 'ASDF'
TEST_VAR3 = 'ASDF'
TEST_VAR4 = 'ASDF'
TEST_VAR5 = 'ASDF'
